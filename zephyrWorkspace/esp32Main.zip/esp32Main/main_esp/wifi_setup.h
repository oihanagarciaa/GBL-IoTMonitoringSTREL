
void init_wifi();

void publishESPMessage(char* id, char* message);
